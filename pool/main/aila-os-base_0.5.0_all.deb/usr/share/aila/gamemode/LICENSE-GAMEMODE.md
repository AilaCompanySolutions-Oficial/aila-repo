# Termos de Uso do Aila Game Mode

> RASCUNHO: este texto precisa ser revisado por um advogado e preenchido com os dados do vendedor (um adulto ou empresa) antes de vender.

**Vendedor:** [NOME COMPLETO DO RESPONSAVEL / CNPJ] — contato: [E-MAIL DE SUPORTE]

## 1. O que voce esta comprando
O Aila Game Mode ("Programa") e um recurso adicional do Aila OS, vendido por **R$ 29,90, pagamento unico**, para uso pessoal em
seus proprios computadores. A licenca e pessoal e intransferivel. O restante do Aila OS continua sob as suas proprias licencas
livres (GPL e outras) e nao e afetado por estes Termos.

## 2. Pagamento
O pagamento e processado pelo Stripe. Nao guardamos dados do seu cartao. A chave de licenca e entregue depois da confirmacao do pagamento.

## 3. Reembolso
Voce tem o **direito de arrependimento de 7 dias** a partir da compra, por ser compra feita pela internet (Codigo de Defesa do
Consumidor, art. 49). Dentro desse prazo, devolvemos o valor pago. **Depois desse prazo nao ha reembolso**, exceto quando a lei exigir.
Para pedir, escreva para o contato acima com o e-mail usado na compra.

## 4. Sem garantia de desempenho
O Programa e fornecido "como esta". O ganho de desempenho em jogos varia conforme o computador e o jogo e **nao e garantido**.
O Programa pausa servicos, fecha aplicativos que **voce** escolher e muda a prioridade de processos. Salve seu trabalho antes de usar.

## 5. Limitacao de responsabilidade
Na maxima extensao permitida pela lei, o vendedor **nao se responsabiliza** por perdas ou danos decorrentes do uso do Programa,
incluindo perda de dados, de progresso em jogos, de contas ou punicoes em jogos online (alguns jogos com anti-cheat podem
reagir a mudancas de prioridade de processos; o uso nesses jogos e por sua conta e risco). Isto nao limita a responsabilidade
que a lei nao permite limitar, como a por dolo ou culpa grave e a prevista no Codigo de Defesa do Consumidor.

## 6. Uso permitido
Voce nao pode compartilhar nem revender a sua chave de licenca, nem tentar burlar a verificacao de licenca. O vendedor pode
invalidar chaves usadas em desacordo com estes Termos.

## 7. Mudancas e lei aplicavel
Estes Termos podem ser atualizados; a versao valida e a vigente na data da compra. Aplica-se a lei brasileira, e o foro e o do
domicilio do consumidor.
