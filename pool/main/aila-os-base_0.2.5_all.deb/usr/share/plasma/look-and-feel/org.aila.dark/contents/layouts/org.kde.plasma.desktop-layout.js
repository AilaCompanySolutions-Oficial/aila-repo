// Layout do Aila OS: barra superior limpa + dock flutuante centralizado (Plasma 6).
var LAUNCHERS = ["applications:brave-browser.desktop", "applications:org.kde.dolphin.desktop", "applications:org.kde.konsole.desktop", "applications:org.kde.kate.desktop", "applications:org.kde.discover.desktop", "applications:systemsettings.desktop"];

// ---------- Barra superior ----------
var top = new Panel;
top.location = "top";
top.height = 34;
try { top.floating = false; } catch (e) {}
try { top.opacity = "translucent"; } catch (e) {}

var menu = top.addWidget("org.kde.plasma.kickoff");
menu.currentConfigGroup = ["Shortcuts"]; menu.writeConfig("global", "Alt+F1");
menu.currentConfigGroup = ["General"];
menu.writeConfig("icon", "aila-symbol");
menu.writeConfig("favoritesPortedToKAstats", "true");
top.addWidget("org.kde.plasma.appmenu");
top.addWidget("org.kde.plasma.panelspacer");
var clock = top.addWidget("org.kde.plasma.digitalclock");
clock.currentConfigGroup = ["Appearance"];
clock.writeConfig("showDate", "true");
clock.writeConfig("dateFormat", "shortDate");
top.addWidget("org.kde.plasma.panelspacer");
// Bandeja: Wi-Fi, Bluetooth, som, bateria e notificacoes ficam aqui.
top.addWidget("org.kde.plasma.systemtray");
// Menu de desligar/bloquear/sair
top.addWidget("org.kde.plasma.lock_logout");

// ---------- Dock inferior ----------
var dock = new Panel;
dock.location = "bottom";
dock.height = 64;
dock.alignment = "center";
try { dock.lengthMode = "fit"; } catch (e) {}
try { dock.floating = true; } catch (e) {}
try { dock.hiding = "dodgewindows"; } catch (e) {}
try { dock.opacity = "translucent"; } catch (e) {}
var tasks = dock.addWidget("org.kde.plasma.icontasks");
tasks.currentConfigGroup = ["General"];
tasks.writeConfig("launchers", LAUNCHERS);
tasks.writeConfig("showToolTips", "true");
tasks.writeConfig("groupingStrategy", "0");
dock.addWidget("org.kde.plasma.trash");
