import QtQuick
import QtQuick.Controls
import QtQuick.Layouts

Rectangle {
    id: root
    width: 1280; height: 720
    color: "#05070D"
    property color accent: "#4C9AFF"
    property bool failed: false

    Image { anchors.fill: parent; source: "background.jpg"; fillMode: Image.PreserveAspectCrop }
    Rectangle { anchors.fill: parent; color: "#000000"; opacity: 0.25 }

    Connections {
        target: sddm
        function onLoginFailed() { root.failed = true; pass.text = ""; pass.forceActiveFocus() }
    }

    ColumnLayout {
        anchors.centerIn: parent
        spacing: 16
        width: 320

        Image { source: "logo.png"; Layout.alignment: Qt.AlignHCenter; Layout.preferredWidth: 96; Layout.preferredHeight: 96; fillMode: Image.PreserveAspectFit }
        Text { text: "Aila OS"; color: "#E9ECF2"; font.pixelSize: 26; font.family: "Inter"; font.weight: Font.DemiBold; Layout.alignment: Qt.AlignHCenter }

        ComboBox {
            id: user
            Layout.fillWidth: true
            model: userModel
            textRole: "name"
            currentIndex: userModel.lastIndex >= 0 ? userModel.lastIndex : 0
        }
        TextField {
            id: pass
            Layout.fillWidth: true
            placeholderText: "Senha"
            echoMode: TextInput.Password
            focus: true
            onAccepted: sddm.login(user.currentText, pass.text, sessionBox.currentIndex)
            background: Rectangle { radius: 10; color: "#1E2845"; border.color: root.failed ? "#DA4453" : root.accent; border.width: pass.activeFocus ? 2 : 1 }
            color: "#E9ECF2"
        }
        Text { visible: root.failed; text: "Senha incorreta. Tente novamente."; color: "#FF8A95"; Layout.alignment: Qt.AlignHCenter; font.family: "Inter" }
        Button {
            Layout.fillWidth: true
            text: "Entrar"
            onClicked: sddm.login(user.currentText, pass.text, sessionBox.currentIndex)
        }
    }

    RowLayout {
        anchors { left: parent.left; bottom: parent.bottom; margins: 24 }
        spacing: 12
        ComboBox { id: sessionBox; model: sessionModel; textRole: "name"; currentIndex: sessionModel.lastIndex; implicitWidth: 200 }
    }
    RowLayout {
        anchors { right: parent.right; bottom: parent.bottom; margins: 24 }
        spacing: 12
        Button { text: "Suspender"; visible: sddm.canSuspend; onClicked: sddm.suspend() }
        Button { text: "Reiniciar"; visible: sddm.canReboot; onClicked: sddm.reboot() }
        Button { text: "Desligar"; visible: sddm.canPowerOff; onClicked: sddm.powerOff() }
    }
    Text { anchors { top: parent.top; right: parent.right; margins: 24 } color: "#E9ECF2"; font.family: "Inter"; font.pixelSize: 16
        text: Qt.formatDateTime(new Date(), "ddd, d MMM  HH:mm") }
}
