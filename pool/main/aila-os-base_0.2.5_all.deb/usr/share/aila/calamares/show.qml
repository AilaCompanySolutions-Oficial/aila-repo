import QtQuick 2.0
import calamares.slideshow 1.0

Presentation {
    id: presentation
    Timer {
        interval: 7000
        running: presentation.activatedInCalamares
        repeat: true
        onTriggered: presentation.goToNextSlide()
    }

    Slide {
        Rectangle { anchors.fill: parent; color: "#0E1424"
            Image { id: logo1; source: "aila-symbol.png"; width: 120; height: 120; fillMode: Image.PreserveAspectFit
                    anchors.horizontalCenter: parent.horizontalCenter; y: parent.height * 0.14 }
            Text { anchors.top: logo1.bottom; anchors.topMargin: 24; anchors.horizontalCenter: parent.horizontalCenter
                   text: "Bem-vindo ao Aila OS"; color: "#E9ECF2"; font.pixelSize: 30; font.bold: true }
            Text { anchors.horizontalCenter: parent.horizontalCenter; y: parent.height * 0.58; width: parent.width * 0.8
                   horizontalAlignment: Text.AlignHCenter; wrapMode: Text.WordWrap; color: "#9AA5BD"; font.pixelSize: 17
                   text: "Leve, bonito e feito para o dia a dia: estudo, trabalho, programação e mídia." }
        }
    }
    Slide {
        Rectangle { anchors.fill: parent; color: "#0E1424"
            Text { anchors.horizontalCenter: parent.horizontalCenter; y: parent.height * 0.30; color: "#4C9AFF"; font.pixelSize: 30; font.bold: true; text: "Tudo no lugar" }
            Text { anchors.horizontalCenter: parent.horizontalCenter; y: parent.height * 0.46; width: parent.width * 0.8
                   horizontalAlignment: Text.AlignHCenter; wrapMode: Text.WordWrap; color: "#E9ECF2"; font.pixelSize: 18
                   text: "Dock embaixo, barra limpa em cima e busca rápida com a tecla Super. Encaixe janelas com Super + setas." }
        }
    }
    Slide {
        Rectangle { anchors.fill: parent; color: "#0E1424"
            Text { anchors.horizontalCenter: parent.horizontalCenter; y: parent.height * 0.30; color: "#4C9AFF"; font.pixelSize: 30; font.bold: true; text: "Pronto para usar" }
            Text { anchors.horizontalCenter: parent.horizontalCenter; y: parent.height * 0.46; width: parent.width * 0.8
                   horizontalAlignment: Text.AlignHCenter; wrapMode: Text.WordWrap; color: "#E9ECF2"; font.pixelSize: 18
                   text: "Brave, Wine e Flatpak já vêm configurados. Instale mais aplicativos pela Loja." }
        }
    }
    Slide {
        Rectangle { anchors.fill: parent; color: "#0E1424"
            Text { anchors.horizontalCenter: parent.horizontalCenter; y: parent.height * 0.30; color: "#4C9AFF"; font.pixelSize: 30; font.bold: true; text: "Sempre atualizado" }
            Text { anchors.horizontalCenter: parent.horizontalCenter; y: parent.height * 0.46; width: parent.width * 0.8
                   horizontalAlignment: Text.AlignHCenter; wrapMode: Text.WordWrap; color: "#E9ECF2"; font.pixelSize: 18
                   text: "O aplicativo Atualizações cuida do sistema e dos apps. Sem precisar reinstalar nada." }
        }
    }
    Slide {
        Rectangle { anchors.fill: parent; color: "#0E1424"
            Text { anchors.horizontalCenter: parent.horizontalCenter; y: parent.height * 0.30; color: "#4C9AFF"; font.pixelSize: 30; font.bold: true; text: "Quase lá!" }
            Text { anchors.horizontalCenter: parent.horizontalCenter; y: parent.height * 0.46; width: parent.width * 0.8
                   horizontalAlignment: Text.AlignHCenter; wrapMode: Text.WordWrap; color: "#E9ECF2"; font.pixelSize: 18
                   text: "Quando a instalação terminar, reinicie o computador e retire o pendrive." }
        }
    }
}
