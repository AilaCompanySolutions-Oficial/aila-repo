[Appearance]
ColorScheme=AilaGlass
Font=JetBrains Mono,10,-1,5,50,0,0,0,0,0

[General]
Name=Aila
Parent=FALLBACK/

[Scrolling]
ScrollBarPosition=2
