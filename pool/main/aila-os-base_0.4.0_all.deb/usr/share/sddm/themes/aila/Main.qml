import QtQuick
import QtQuick.Controls
import QtQuick.Layouts

// Login do Aila OS: relogio grande, cartao de vidro, avatar com a logo, animacoes suaves.
Rectangle {
    id: root
    width: 1280; height: 720
    color: "#05070D"
    property color accent: "#4C9AFF"
    property bool failed: false
    readonly property string ui: "Inter"

    function doLogin() { sddm.login(user.currentText, pass.text, sessionBox.currentIndex) }

    Image { id: bg; anchors.fill: parent; source: "background.jpg"; fillMode: Image.PreserveAspectCrop; smooth: true }
    Rectangle {
        anchors.fill: parent
        gradient: Gradient {
            GradientStop { position: 0.0; color: "#55000000" }
            GradientStop { position: 1.0; color: "#99000000" }
        }
    }

    Connections {
        target: sddm
        function onLoginFailed() { root.failed = true; pass.text = ""; shake.start(); pass.forceActiveFocus() }
    }

    // ---- Relogio ----
    Column {
        anchors { horizontalCenter: parent.horizontalCenter; top: parent.top; topMargin: root.height * 0.09 }
        spacing: 2
        Text {
            id: timeText
            anchors.horizontalCenter: parent.horizontalCenter
            color: "#F4F7FC"; font.family: root.ui; font.weight: Font.Light
            font.pixelSize: Math.max(64, root.height * 0.12)
            text: Qt.formatTime(new Date(), "HH:mm")
        }
        Text {
            id: dateText
            anchors.horizontalCenter: parent.horizontalCenter
            color: "#C9D3E6"; font.family: root.ui; font.pixelSize: 20
            text: Qt.formatDate(new Date(), "dddd, d 'de' MMMM")
        }
    }
    Timer {
        interval: 1000; running: true; repeat: true
        onTriggered: { var d = new Date(); timeText.text = Qt.formatTime(d, "HH:mm"); dateText.text = Qt.formatDate(d, "dddd, d 'de' MMMM") }
    }

    // ---- Cartao de vidro ----
    Item {
        id: card
        width: 400; height: 340
        anchors.horizontalCenter: parent.horizontalCenter
        y: root.height * 0.40
        opacity: 0
        NumberAnimation on opacity { from: 0; to: 1; duration: 700; easing.type: Easing.OutCubic }

        Loader {
            id: glass
            anchors.fill: parent
            source: "GlassBlur.qml"
            onLoaded: {
                item.imageSource = bg.source
                item.fullW = Qt.binding(function() { return root.width })
                item.fullH = Qt.binding(function() { return root.height })
                item.offX = Qt.binding(function() { return card.x })
                item.offY = Qt.binding(function() { return card.y })
            }
        }
        Rectangle {   // pele do vidro
            anchors.fill: parent; radius: 28
            color: glass.status === Loader.Ready ? "#22FFFFFF" : "#B010182C"
            border.width: 1; border.color: "#48FFFFFF"
        }
        Rectangle {   // brilho no topo
            anchors { left: parent.left; right: parent.right; top: parent.top; margins: 1 }
            height: parent.height * 0.5; radius: 27
            gradient: Gradient {
                GradientStop { position: 0.0; color: "#26FFFFFF" }
                GradientStop { position: 1.0; color: "#00FFFFFF" }
            }
        }

        ColumnLayout {
            id: content
            anchors.fill: parent; anchors.margins: 28
            spacing: 14
            transform: Translate { id: shakeT; x: 0 }

            Rectangle {
                Layout.alignment: Qt.AlignHCenter
                Layout.preferredWidth: 84; Layout.preferredHeight: 84
                radius: 42; color: "#33FFFFFF"; border.width: 2; border.color: root.accent
                Image { anchors.centerIn: parent; width: 52; height: 52; source: "logo.png"; fillMode: Image.PreserveAspectFit; smooth: true }
            }
            Text {
                visible: userModel.count <= 1
                Layout.alignment: Qt.AlignHCenter
                text: user.currentText; color: "#F4F7FC"; font.family: root.ui; font.pixelSize: 22; font.weight: Font.DemiBold
            }
            ComboBox {
                id: user
                visible: userModel.count > 1
                Layout.fillWidth: true
                model: userModel; textRole: "name"
                currentIndex: userModel.lastIndex >= 0 ? userModel.lastIndex : 0
            }
            TextField {
                id: pass
                Layout.fillWidth: true; Layout.preferredHeight: 48
                placeholderText: "Senha"; placeholderTextColor: "#AAB6CC"
                echoMode: TextInput.Password
                color: "#F4F7FC"; font.family: root.ui; font.pixelSize: 16
                leftPadding: 18; rightPadding: 56
                focus: true
                onAccepted: root.doLogin()
                onTextChanged: root.failed = false
                background: Rectangle {
                    radius: 24; color: "#33000000"
                    border.width: pass.activeFocus ? 2 : 1
                    border.color: root.failed ? "#FF6B7A" : (pass.activeFocus ? root.accent : "#44FFFFFF")
                }
                Button {
                    id: go
                    anchors { right: parent.right; rightMargin: 6; verticalCenter: parent.verticalCenter }
                    width: 38; height: 38
                    contentItem: Text { text: "→"; color: "white"; font.pixelSize: 20; horizontalAlignment: Text.AlignHCenter; verticalAlignment: Text.AlignVCenter }
                    background: Rectangle { radius: 19; color: go.down ? "#2B86FF" : root.accent }
                    onClicked: root.doLogin()
                }
            }
            Text {
                visible: root.failed
                Layout.alignment: Qt.AlignHCenter
                text: "Senha incorreta. Tente novamente."; color: "#FF8A95"; font.family: root.ui; font.pixelSize: 14
            }
            Item { Layout.fillHeight: true }
            Text {
                Layout.alignment: Qt.AlignHCenter
                text: "Aila OS"; color: "#9AA5BD"; font.family: root.ui; font.pixelSize: 13
            }
        }
        SequentialAnimation {
            id: shake
            NumberAnimation { target: shakeT; property: "x"; to: -12; duration: 50 }
            NumberAnimation { target: shakeT; property: "x"; to: 12; duration: 70 }
            NumberAnimation { target: shakeT; property: "x"; to: -8; duration: 60 }
            NumberAnimation { target: shakeT; property: "x"; to: 0; duration: 50 }
        }
    }

    // ---- Rodape: sessao e energia ----
    RowLayout {
        anchors { left: parent.left; bottom: parent.bottom; margins: 24 }
        ComboBox {
            id: sessionBox
            model: sessionModel; textRole: "name"; currentIndex: sessionModel.lastIndex
            implicitWidth: 200
        }
    }
    RowLayout {
        anchors { right: parent.right; bottom: parent.bottom; margins: 24 }
        spacing: 10
        GlassButton { text: "Suspender"; visible: sddm.canSuspend; onClicked: sddm.suspend() }
        GlassButton { text: "Reiniciar"; visible: sddm.canReboot; onClicked: sddm.reboot() }
        GlassButton { text: "Desligar"; visible: sddm.canPowerOff; onClicked: sddm.powerOff() }
    }
    Component.onCompleted: pass.forceActiveFocus()
}
