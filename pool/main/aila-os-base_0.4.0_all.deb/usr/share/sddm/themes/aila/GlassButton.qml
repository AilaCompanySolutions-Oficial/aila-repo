import QtQuick
import QtQuick.Controls

Button {
    id: b
    property color tint: "#26FFFFFF"
    implicitHeight: 40
    implicitWidth: contentItem.implicitWidth + 36
    font.family: "Inter"
    font.pixelSize: 14
    contentItem: Text {
        text: b.text; color: "#F4F7FC"; font: b.font
        horizontalAlignment: Text.AlignHCenter; verticalAlignment: Text.AlignVCenter
    }
    background: Rectangle {
        radius: height / 2
        color: b.down ? "#55FFFFFF" : (b.hovered ? "#40FFFFFF" : b.tint)
        border.width: 1; border.color: "#40FFFFFF"
    }
}
