// Vidro de verdade: desfoca o pedaco do papel de parede que fica atras do cartao.
// Se o modulo QtQuick.Effects nao existir, o Main.qml carrega sem este arquivo (cartao translucido simples).
import QtQuick
import QtQuick.Effects

Item {
    id: gb
    property url imageSource
    property real fullW: 1280
    property real fullH: 720
    property real offX: 0
    property real offY: 0
    property real cornerRadius: 28

    Item {
        id: inner
        anchors.fill: parent
        visible: false
        clip: true
        Image {
            x: -gb.offX; y: -gb.offY
            width: gb.fullW; height: gb.fullH
            source: gb.imageSource
            fillMode: Image.PreserveAspectCrop
        }
    }
    Item {
        id: maskItem
        anchors.fill: parent
        visible: false
        layer.enabled: true
        Rectangle { anchors.fill: parent; radius: gb.cornerRadius; color: "white" }
    }
    MultiEffect {
        anchors.fill: parent
        source: inner
        blurEnabled: true
        blur: 1.0
        blurMax: 40
        saturation: 0.25
        brightness: 0.05
        maskEnabled: true
        maskSource: maskItem
    }
}
